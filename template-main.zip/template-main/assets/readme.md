
Clique no lápis à direita para editar essa página.

Coloque nessa pasta assets, todas as figuras que vão aparecer na sua documentação.

Use os comandos abaixo para citar as imagens no seu doc.


<img src="https://github.com/agodoi/template/blob/main/assets/logo-fiap.png" width="200">

coloque o comando entre < >
o parânetro src indica o path da figura
O parâmetro "width=200" indica o tamanho da figura.
